<?php
include "../modelo/Perro.php";
$users= Perro::getPerrosPDO();
echo json_encode($users, JSON_UNESCAPED_UNICODE);
?>