<?php
if (!empty($_POST["btnC"])) {
    if (
        !empty($_POST["id1"])
        && (!empty($_POST["id2"]))
    ) {
        $p1 = Perro::getPerroBD($_POST["id1"]);
        $p2 = Perro::getPerroBD($_POST["id2"]);
        $cachorro = Perro::getCachorro($p1, $p2);
        if ($cachorro != null) {
            Perro::insertarPerro($cachorro);
        }else{
            $s1=$p1->getSexo();
            $s2=$p2->getSexo();
            echo '<div class="alert alert-danger">No es posible el cruce entre:'.$s1.' y '.$s2.'</div>';
        }
        echo '<div class="alert alert-warning">Algunos de los campos estan vacios</div>';
    }
}
