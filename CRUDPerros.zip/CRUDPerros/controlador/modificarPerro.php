<?php
if (!empty($_POST["btnModi"])) {
    if (
        !empty($_POST["nombre"])
        and !empty($_POST["raza"])
        and !empty($_POST["color"])
        and !empty($_POST["peso"])
        and !empty($_POST["sexo"])
        and !empty($_POST["id"])
    ) {
        $nombre = $_POST["nombre"];
        $raza = $_POST["raza"];
        $color = $_POST["color"];
        $peso = $_POST["peso"];
        $sexo = $_POST["sexo"];
        $i = $_POST["id"];
        $perro = new Perro($nombre,$raza,$color,$peso,$sexo,$i);
        $resul = Perro::modificarEnBd($perro);
        if($resul == 1){
            header("location:../index.php");
        }else{
            echo '<div class="alert alert-danger">Error al modificar Perro</div>';
        }
    } else {
        echo '<div class="alert alert-warning">Algunos de los campos estan vacios</div>';
    }
}
