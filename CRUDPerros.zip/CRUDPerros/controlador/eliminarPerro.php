<?php
if(!empty($_GET["id"])){
    $id = $_GET["id"];
    $resul = Perro::eliminar($id);
    if($resul == 1){
        echo '<div class="alert alert-success">Perro eliminado correctamente</div>';
        header("location:index.php");
    }else{
        echo '<div class="alert alert-danger">Perro no se ha podido eliminar correctamente </div>';
    }
}
?>