---
title: Briefcase
categories:
  - Real world
tags:
  - business
  - bag
  - baggage
---
