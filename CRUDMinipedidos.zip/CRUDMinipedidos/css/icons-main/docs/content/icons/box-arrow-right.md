---
title: Box arrow right
categories:
  - Box arrows
tags:
  - arrow
  - logout
  - signout
  - exit
---
