---
title: Caret right fill
categories:
  - Carets
tags:
  - caret
  - arrow
  - triangle
---
