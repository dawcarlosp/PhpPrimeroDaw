<?php
if (!empty($_POST["btnModi"])) {
    if (
        !empty($_POST["nombre"])
        and !empty($_POST["precio"])
        and !empty($_POST["stock"])
        and !empty($_POST["id"])
    ) {
        $nombre = $_POST["nombre"];
        $precio = $_POST["precio"];
        $stock = $_POST["stock"];
        $id = $_POST["id"];
        $pro = new Producto($nombre,$precio,$stock,$id);
        $resul = Producto::modificarEnBd2($pro);
        if($resul == 1){
            header("location:../index.php");
        }else{
            echo '<div class="alert alert-danger">Error al modificar Producto</div>';
        }
    } else {
        echo '<div class="alert alert-warning">Algunos de los campos estan vacios</div>';
    }
}
