<?php
include "../modelo/Producto.php";
$pros= Producto::getProductosPDO();
echo json_encode($pros, JSON_UNESCAPED_UNICODE);
?>