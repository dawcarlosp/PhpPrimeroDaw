<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["btnPedido"])) {
        if (!empty($_POST["id"]) && !empty($_POST["cantidad"])) {
            $id = $_POST["id"];
            $cantidad = $_POST["cantidad"];
            $resul = Producto::pedido($id, $cantidad);
            $im = Producto::calImporte($id, $cantidad);
            if ($resul == 1) {
                // Redirigir con un mensaje de éxito
                header("Location: ../vista/Minipedido.php?status=success&importe=$im");
                exit();
            } else {
                // Redirigir con un mensaje de error
                header("Location: ../vista/Minipedido.php?status=error");
                exit();
            }
        } else {
            // Redirigir con un mensaje de advertencia
            header("Location: ../vista/Minipedido.php?status=warning");
            exit();
        }
    }
} else {
    // Mostrar mensajes basados en el parámetro 'status' en la URL
    if (isset($_GET['status'])) {
        if ($_GET['status'] === 'success' && isset($_GET['importe'])) {
            echo '<div class="alert alert-success">Pedido realizado correctamente</div>';
            echo '<div class="alert alert-success">Importe: ' . htmlspecialchars($_GET['importe']) . '</div>';
        } elseif ($_GET['status'] === 'error') {
            echo '<div class="alert alert-danger">Error al realizar pedido</div>';
        } elseif ($_GET['status'] === 'warning') {
            echo '<div class="alert alert-warning">Algunos de los campos están vacíos</div>';
        }
    }
}
?>
