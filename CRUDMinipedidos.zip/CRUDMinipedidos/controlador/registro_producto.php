<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST["btnG"])) {
        if (!empty($_POST["nombre"]) && !empty($_POST["precio"]) && !empty($_POST["stock"])) {
            $nombre = $_POST["nombre"];
            $precio = $_POST["precio"];
            $stock = $_POST["stock"];
            $pro = new Producto($nombre, $precio, $stock);
            $resul = Producto::insertarProEnBd($pro);
            if ($resul == 1) {
                // Redirigir con un mensaje de éxito
                header("Location: index.php?status=success");
                exit();
            } else {
                // Redirigir con un mensaje de error
                header("Location: index.php?status=error");
                exit();
            }
        } else {
            // Redirigir con un mensaje de advertencia
            header("Location: index.php?status=warning");
            exit();
        }
    }
} else {
    // Mostrar mensajes basados en el parámetro 'status' en la URL
    if (isset($_GET['status'])) {
        if ($_GET['status'] === 'success') {
            echo '<div class="alert alert-success">Producto registrado correctamente</div>';
        } elseif ($_GET['status'] === 'error') {
            echo '<div class="alert alert-danger">Error al registrar producto</div>';
        } elseif ($_GET['status'] === 'warning') {
            echo '<div class="alert alert-warning">Algunos de los campos están vacíos</div>';
        }
    }
}
?>
