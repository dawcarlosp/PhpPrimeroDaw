<?php
include "../modelo/Usuario.php";
$users= Usuario::getUsuariosPDO();
echo json_encode($users, JSON_UNESCAPED_UNICODE);
?>