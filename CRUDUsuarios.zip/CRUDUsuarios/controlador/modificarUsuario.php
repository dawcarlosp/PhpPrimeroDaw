<?php
if (!empty($_POST["btnModi"])) {
    if (
        !empty($_POST["usuario"])
        and !empty($_POST["password"])
        and !empty($_POST["id"])
    ) {
        $user = $_POST["usuario"];
        $pas = $_POST["password"];
        $i = $_POST["id"];
        $usuario = new Usuario($user,$pas,$i);
        $resul = Usuario::modificarEnBd($usuario);
        if($resul == 1){
            header("location:../index.php");
        }else{
            echo '<div class="alert alert-danger">Error al modificar Producto</div>';
        }
    } else {
        echo '<div class="alert alert-warning">Algunos de los campos estan vacios</div>';
    }
}
